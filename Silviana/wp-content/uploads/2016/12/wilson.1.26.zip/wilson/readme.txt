Copyright
--------------

Wilson WordPress Theme, Copyright 2014 Anders Norén
Wilson is distributed under the terms of the GNU GPL v2


Install Steps
--------------

1. Upload the theme
2. Activate the theme


Licenses
--------------

Lato font license : SIL Open Font License, 1.1 http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

Raleway font license : SIL Open Font License, 1.1 http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

screenshot.png post image license : Public Domain (CC0) http://en.wikipedia.org/wiki/Public_domain